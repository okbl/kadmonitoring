globalThis.KAD_CONFIG = {"base":"https://kad.arbitr.ru"};
